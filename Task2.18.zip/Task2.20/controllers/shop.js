const User = require('../models/User');

exports.getUsers = (req, res, next) => {
  User.findAll()
    .then(users => {
      res.render('user/user-list', {
        prods: users,
        pageTitle: 'All Appoinments',
        path: '/users'
      });
    })
    .catch(err => {
      console.log(err);
      res.status(500).send('Internal Server Error');
    });
};



exports.getIndex = (req, res, next) => {
  User.findAll()
    .then(users => {
      res.render('user/index', {
        prods: users,
        pageTitle: 'Appoinments',
        path: '/'
      });
    })
    .catch(err => {
      console.log(err);
      res.status(500).send('Internal Server Error');
    });
};

