const User = require('../models/User');

exports.getAddUser = (req, res, next) => {
  res.render('admin/edit-appoinment', {
    pageTitle: 'Book Appoinment',
    path: '/admin/book-appoinment',
    editing: false
  });
};

exports.postAddUser = async (req, res, next) => {
  const username = req.body.username;
  const number = req.body.number;
  const email = req.body.email;
  try {
    const data = await User.create({
      username: username,
      number: number,
      email: email
    });
    res.redirect('/users');
  } catch(error) {
    console.log(error);
    res.redirect('/404');
  }
};

exports.postDeleteUser = async (req, res) => {
  const userId = req.params.userId;

  try{ 
    await User.destroy({
      where: { id: userId }
    });
    res.redirect('/users');
  } catch(error) {
    console.log(error);
    res.status(500).send('Internal Server Error');
  }
};

/*exports.getEditUser = (req, res, next) => {
  const editMode = req.query.edit;
  if(!editMode) {
    return res.redirect('/users');
  }
  const usersId = req.params.userId;
  User.findByPk(usersId, (err,user) => {
    if(err || !user){
      return res.redirect('/users');
    }
    res.render('admin/edit-appoinment', {
      pageTitle: 'Edit Details',
      path: '/admin/edit-details',
      editing: editMode,
      user: user
    });
  });
};*/


exports.getUsers = (req, res, next) => {
  User.findAll()
  .then(users => {
    res.render('admin/users', {
      prods: users,
      pageTitle: 'Edit Details',
      path: '/admin/users'
    });
  })
  .catch(err => {
    console.log(err);
  });
};
