const path = require('path');

const express = require('express');

const userController = require('../controllers/shop');

const router = express.Router();

router.get('/', userController.getIndex);

router.get('/users', userController.getUsers);




module.exports = router;
