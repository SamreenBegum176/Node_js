const path = require('path');

const express = require('express');

const adminController = require('../controllers/admin');

const router = express.Router();

// /admin/add-product => GET
router.get('/book-appoinment', adminController.getAddUser);

// /admin/products => GET
router.get('/users', adminController.getUsers);

// /admin/add-product => POST
router.post('/book-appoinment', adminController.postAddUser);

//router.get('/edit-user/:userId', adminController.getEditUser);

router.post('/delete-user/:userId', adminController.postDeleteUser);

module.exports = router;
