const Sequelize = require('sequelize');

const sequelize = new Sequelize('bookingapp', 'root', 'sam123', {
    dialect: 'mysql',
    logging: false,
    host: 'localhost'
});

module.exports = sequelize;