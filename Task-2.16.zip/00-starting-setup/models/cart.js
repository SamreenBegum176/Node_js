
const db = require('../util/database');

module.exports = class Cart {
  static addProduct(id, productPrice) {
    const sql = 'INSERT INTO cart (productId, qty, totalPrice) VALUES (?, 1, ?) ON DUPLICATE KEY UPDAtE qty =qty + 1, totalPrice = totalPrice + ?';
    db.execute(sql, [id, productPrice, productPrice])
      .then(result => {
        console.log('Product added to cart.');
      })
      .catch(err => console.log(err));
  }

  static deleteProduct(id, productPrice) {
    const sql = 'DELETE FROM cart WHERE productId = ?';
    db.execute(sql, [id])
      .then(result => {
        console.log('Product deleted from cart.');
      })
      .catch(err => console.log(err));
  }

  static getCart(cb) {
    return db.execute('SELECT * FROM cart')
      .then(([rows, fields]) => {
        return rows;
      })
      .catch(err => {
        console.log(err);
        return null;
      });
  }
};
