const Product = require('../models/product');

const form = [];

exports.getAddProduct = (req, res, next) => {
    res.render('add-product', {
      pageTitle: 'Add Product',
      path: '/admin/add-product',
      formsCSS: true,
      productCSS: true,
      activeAddProduct: true
    });
}

exports.postAddProduct = (req, res, next) => {
    const product = new Product(req.body.title);
    product.save();
    res.redirect('/');
}


exports.getProducts = (req, res, next) => {
    const products = Product.fetchAll(products => {
        res.render('shop', {
            prods: products,
            pageTitle: 'Shop',
            path: '/',
            hasProducts: products.length > 0,
            activeShop: true,
            productCSS: true
        });
    });
}

exports.getAddForm = (req, res, next) =>{
    res.render('contact-us', {
        pageTitle: 'Contact Us',
        path: '/contact-us',
        formsCSS: true,
        activeShop: true,
        productCSS: true
    });
}

exports.postAddForm = (req, res, next) => {
    const username = req.body.username;
    const email = req.body.email;

    form.push({username: username, email: email});
    res.render('sucess', {
        prods: form,
        pageTitle: "Sucess",
        path: '/sucess',
        formsCSS: true,
        activeShop: true,
        productCSS: true
    });
}
