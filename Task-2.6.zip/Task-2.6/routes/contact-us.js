const path = require('path');

const express = require('express');

const FormController = require('../controllers/product');

const router = express.Router();

router.get('/contact-us', FormController.getAddForm);

router.post('/contact-us', FormController.postAddForm);

module.exports = router;